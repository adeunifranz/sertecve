<?php
/**
 * FAL.php
 * @author Revin Roman
 * @link https://rmrevin.ru
 */

namespace rmrevin\yii\fontawesome;

/**
 * Class FAL
 * @package rmrevin\yii\fontawesome
 */
class FAL extends FontAwesome
{
    public static $cssPrefix = 'fal';
}
